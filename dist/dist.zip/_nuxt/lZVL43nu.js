const a={primary:"#3498db",secondary:"#f1c40f",accent:"#8e44ad"};export{a as default};
