import{aa as e,ab as a,ac as s}from"./CyPEYCpI.js";const u=e(async()=>{if(a().value)return s("/dashboard",{replace:!0})});export{u as default};
