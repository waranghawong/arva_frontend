import{aa as e,ab as a,ac as r}from"./CyPEYCpI.js";const u=e(async()=>{if(!a().value)return r("/login",{replace:!0})});export{u as default};
